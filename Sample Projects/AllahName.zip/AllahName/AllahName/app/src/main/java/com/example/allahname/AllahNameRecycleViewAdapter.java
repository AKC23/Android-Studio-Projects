package com.example.allahname;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AllahNameRecycleViewAdapter extends RecyclerView.Adapter<AllahNameRecycleViewAdapter.ViewHolder> {
    private ArrayList<Name>names=new ArrayList<>();
    private Context context;
    public AllahNameRecycleViewAdapter(Context context) {
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.name_layout,parent,false);
       ViewHolder holder=new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.no.setText(names.get(position).getId());
        holder.english.setText(names.get(position).getEnglish());
        holder.bangla.setText(names.get(position).getBangla());
        holder.arabic.setText(names.get(position).getArabic());
        holder.translation.setText(names.get(position).getTrans());
    }

    @Override
    public int getItemCount() {
        return names.size();
    }

    public void setNames(ArrayList<Name> names) {
        this.names = names;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView no,bangla,english,arabic,translation;
        private RelativeLayout parent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            no=itemView.findViewById(R.id.id_num);
            bangla=itemView.findViewById(R.id.bengali_name);
            english=itemView.findViewById(R.id.english_name);
            arabic=itemView.findViewById(R.id.arabic_name);
            translation=itemView.findViewById(R.id.bangla_translation);
            parent=itemView.findViewById(R.id.parent);

        }
    }
}
