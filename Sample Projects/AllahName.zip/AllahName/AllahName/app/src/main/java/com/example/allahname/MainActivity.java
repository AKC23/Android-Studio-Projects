package com.example.allahname;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView ANRV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ANRV=findViewById(R.id.AllahnameRV);

        ArrayList<Name>names=new ArrayList<>();
        names.add(new Name("1","আল্লাহ্","Allah","الله","আল্লাহ্"));
        names.add(new Name("2","আর রহিম","Ar-Rahim","الرحيم","পরম করুনাময়"));
        names.add(new Name("3","আর রহমান","Ar-Rahman","الرحمن","পরম দাতা ও দয়ালু"));
        names.add(new Name("4","আল জাব্বার","Al-Jabbar","الجبار","পরাক্রমশালী"));
        names.add(new Name("5","আল ʿআজিজ","Al-Aziz","العزيز","প্রবল"));
        names.add(new Name("6","আল মুহায়মিন","Al-Muhaymin","المهيمن","রক্ষণ ব্যবস্থাকারী"));
        names.add(new Name("7","আল মুʿমিন","Al-Mu'min","المؤمن","একমাত্র নিরাপত্তা দান কারী"));
        names.add(new Name("8","আস সালাম","As-Salam","السلام","শান্তি বিধায়ক"));
        names.add(new Name("9","আল কুদ্দুস","Al-Quddus","القدوس","নিষ্কলুষ"));
        names.add(new Name("10","আল মালিক","Al-Malik","الملك","সর্বাধিকারী"));

        names.add(new Name("11","","","",""));
        names.add(new Name("12","","","",""));
        names.add(new Name("13","","","",""));
        names.add(new Name("14","","","",""));
        names.add(new Name("15","","","",""));
        names.add(new Name("16","","","",""));
        names.add(new Name("17","","","",""));
        names.add(new Name("18","","","",""));
        names.add(new Name("19","","","",""));
        names.add(new Name("20","","","",""));


        names.add(new Name("21","","","",""));
        names.add(new Name("22","","","",""));
        names.add(new Name("23","","","",""));
        names.add(new Name("24","","","",""));
        names.add(new Name("25","","","",""));
        names.add(new Name("26","","","",""));
        names.add(new Name("27","","","",""));
        names.add(new Name("28","","","",""));
        names.add(new Name("29","","","",""));
        names.add(new Name("30","","","",""));

        names.add(new Name("31","","","",""));
        names.add(new Name("32","","","",""));
        names.add(new Name("33","","","",""));
        names.add(new Name("34","","","",""));
        names.add(new Name("35","","","",""));
        names.add(new Name("36","","","",""));
        names.add(new Name("37","","","",""));
        names.add(new Name("38","","","",""));
        names.add(new Name("39","","","",""));
        names.add(new Name("40","","","",""));

        names.add(new Name("41","","","",""));
        names.add(new Name("42","","","",""));
        names.add(new Name("43","","","",""));
        names.add(new Name("44","","","",""));
        names.add(new Name("45","","","",""));
        names.add(new Name("46","","","",""));
        names.add(new Name("47","","","",""));
        names.add(new Name("48","","","",""));
        names.add(new Name("49","","","",""));
        names.add(new Name("50","","","",""));



        names.add(new Name("51","","","",""));
        names.add(new Name("52","","","",""));
        names.add(new Name("53","","","",""));
        names.add(new Name("54","","","",""));
        names.add(new Name("55","","","",""));
        names.add(new Name("56","","","",""));
        names.add(new Name("57","","","",""));
        names.add(new Name("58","","","",""));
        names.add(new Name("59","","","",""));
        names.add(new Name("60","","","",""));

        names.add(new Name("61","","","",""));
        names.add(new Name("62","","","",""));
        names.add(new Name("63","","","",""));
        names.add(new Name("64","","","",""));
        names.add(new Name("65","","","",""));
        names.add(new Name("66","","","",""));
        names.add(new Name("67","","","",""));
        names.add(new Name("68","","","",""));
        names.add(new Name("69","","","",""));
        names.add(new Name("70","","","",""));

        names.add(new Name("71","","","",""));
        names.add(new Name("72","","","",""));
        names.add(new Name("73","","","",""));
        names.add(new Name("74","","","",""));
        names.add(new Name("75","","","",""));
        names.add(new Name("76","","","",""));
        names.add(new Name("77","","","",""));
        names.add(new Name("78","","","",""));
        names.add(new Name("79","","","",""));
        names.add(new Name("80","","","",""));

        names.add(new Name("81","","","",""));
        names.add(new Name("82","","","",""));
        names.add(new Name("83","","","",""));
        names.add(new Name("84","","","",""));
        names.add(new Name("85","","","",""));
        names.add(new Name("86","","","",""));
        names.add(new Name("87","","","",""));
        names.add(new Name("88","","","",""));
        names.add(new Name("89","","","",""));
        names.add(new Name("90","","","",""));

        names.add(new Name("91","আল মুগনী","Al-Mughni","المغني","অভাব মোচনকারী"));
        names.add(new Name("92","আল গানী","Al-Ghani","الغني","সম্পদশালী"));
        names.add(new Name("93","আল জামি","Al-Jami","الجامع","একত্রীকরণকারী"));
        names.add(new Name("94","আস সাবুর","As-Sabur","الصبور","ধৈর্যশীল"));
        names.add(new Name("95","আর রশীদ"," Ar-Rashid","الرشيد","সত্যদর্শী"));
        names.add(new Name("96","আল ওয়ারিছ","Al-Warith","الوارث","উত্তরাধিকারী"));
        names.add(new Name("97","আল বাকী","Al-Baqi","الباقي","চিরস্থায়ী"));
        names.add(new Name("98","আল বাদী","Al-Badi","البديع","অভিনব সৃষ্টিকারী"));
        names.add(new Name("99","আন নূর","An-Nur","النور","জ্যোতি"));

        AllahNameRecycleViewAdapter adapter=new AllahNameRecycleViewAdapter(this);
        adapter.setNames(names);
        ANRV.setAdapter(adapter);
        ANRV.setLayoutManager(new LinearLayoutManager(this));


    }
}