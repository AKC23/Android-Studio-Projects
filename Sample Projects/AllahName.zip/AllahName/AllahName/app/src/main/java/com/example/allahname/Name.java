package com.example.allahname;

public class Name {
    private String id;
    private String bangla;
    private String english;
    private String arabic;
    private String trans;

    public Name(String id, String bangla, String english, String arabic, String trans) {
        this.id = id;
        this.bangla = bangla;
        this.english = english;
        this.arabic = arabic;
        this.trans = trans;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBangla() {
        return bangla;
    }

    public void setBangla(String bangla) {
        this.bangla = bangla;
    }

    public String getEnglish() {
        return english;
    }

    public void setEnglish(String english) {
        this.english = english;
    }

    public String getArabic() {
        return arabic;
    }

    public void setArabic(String arabic) {
        this.arabic = arabic;
    }

    public String getTrans() {
        return trans;
    }

    public void setTrans(String trans) {
        this.trans = trans;
    }

    @Override
    public String toString() {
        return "Name{" +
                "id='" + id + '\'' +
                ", bangla='" + bangla + '\'' +
                ", english='" + english + '\'' +
                ", arabic='" + arabic + '\'' +
                ", trans='" + trans + '\'' +
                '}';
    }
}
